
import { ViciousWizardMain } from '@/components/ViciousWizard/ViciousWizardMain';

export default function Home() {
  return (
    <main className="min-h-screen overflow-hidden">
      <ViciousWizardMain />
    </main>
  );
}
