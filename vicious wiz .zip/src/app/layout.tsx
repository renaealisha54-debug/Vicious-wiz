
import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Vicious Wizard',
  description: 'Unleash arcane power with the Vicious Wizard grimoire.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Mono:wght@300;400;500&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased bg-[#080b14]">
        {children}
      </body>
    </html>
  );
}
