
"use client";

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Sparkles, Loader2, Skull } from 'lucide-react';
import { generateViciousCharacterTraits, type GenerateViciousCharacterTraitsOutput } from '@/ai/flows/generate-vicious-character-traits';
import { useToast } from '@/hooks/use-toast';

interface TraitGeneratorToolProps {
  onLog: (type: 'genai', message: string) => void;
}

export function TraitGeneratorTool({ onLog }: TraitGeneratorToolProps) {
  const [name, setName] = useState('');
  const [type, setType] = useState('Vicious Wizard');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GenerateViciousCharacterTraitsOutput | null>(null);
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!name.trim()) {
      toast({
        title: "Empty Name",
        description: "You must name the entity before imbuing it with darkness.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const output = await generateViciousCharacterTraits({
        characterName: name,
        characterType: type,
      });
      setResult(output);
      onLog('genai', `Infused ${name} (${type}) with dark energy. Result: ${output.traits.join(', ')}`);
    } catch (error) {
      toast({
        title: "Arcane Failure",
        description: "The void refused your request. Try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="vicious-card border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-headline text-xl">
          <Skull className="text-secondary h-5 w-5" />
          Vicious Trait Gen
        </CardTitle>
        <CardDescription className="text-xs font-body">
          Forge backstories in the fires of the void
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="char-name" className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">Entity Name</Label>
          <Input 
            id="char-name"
            placeholder="e.g. Malakor the Cursed" 
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="bg-black/40 border-white/10 font-body text-sm"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="char-type" className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">Entity Class</Label>
          <Input 
            id="char-type"
            placeholder="e.g. Shadow Warlock" 
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="bg-black/40 border-white/10 font-body text-sm"
          />
        </div>

        <Button 
          onClick={handleGenerate} 
          disabled={loading}
          className="w-full bg-gradient-to-r from-primary to-secondary font-headline font-bold uppercase tracking-wider h-11"
        >
          {loading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Sparkles className="mr-2 h-4 w-4" />
          )}
          Invoke Void Intelligence
        </Button>

        {result && (
          <div className="mt-4 p-4 rounded-lg bg-black/40 border border-white/5 space-y-3 animate-in fade-in slide-in-from-top-2 duration-500">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-accent tracking-widest">Aggressive Traits</span>
              <div className="flex flex-wrap gap-1">
                {result.traits.map((trait, idx) => (
                  <span key={idx} className="px-2 py-0.5 rounded-full bg-primary/20 border border-primary/30 text-[10px] text-primary-foreground font-body">
                    {trait}
                  </span>
                ))}
              </div>
            </div>
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold text-accent tracking-widest">Dark Backstory</span>
              <p className="text-xs font-body text-muted-foreground leading-relaxed">
                {result.backstory}
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
