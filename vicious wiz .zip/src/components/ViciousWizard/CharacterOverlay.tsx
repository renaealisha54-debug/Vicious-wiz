
"use client";

import React from 'react';
import { X } from 'lucide-react';
import { CharacterType } from './ViciousWizardMain';
import { cn } from '@/lib/utils';

interface CharacterOverlayProps {
  character: CharacterType | null;
  onClose: () => void;
}

export function CharacterOverlay({ character, onClose }: CharacterOverlayProps) {
  if (!character) return null;

  return (
    <div className="fixed inset-0 z-50 pointer-events-none flex items-center justify-center p-4">
      {/* Background Dimming (Partial) */}
      <div className="absolute inset-0 bg-black/20 backdrop-blur-[2px] pointer-events-auto" onClick={onClose} />
      
      {/* Animated Character Container */}
      <div className="relative pointer-events-auto max-w-lg w-full">
        <div className={cn(
          "relative vicious-card p-12 overflow-hidden flex flex-col items-center justify-center animate-vicious-summon",
          character === 'wizard' ? "border-primary/40 shadow-primary/20" : "border-secondary/40 shadow-secondary/20"
        )}>
          {/* Close button */}
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-2 hover:bg-white/10 rounded-full transition-colors z-10"
          >
            <X className="h-5 w-5 text-muted-foreground" />
          </button>

          {/* Glowing Aura Effect */}
          <div className={cn(
            "absolute inset-0 opacity-20 pointer-events-none",
            character === 'wizard' ? "bg-primary" : "bg-secondary"
          )} />

          {/* The Entity */}
          <div className="relative flex flex-col items-center gap-6">
            <div className={cn(
              "text-9xl animate-bob",
              character === 'wizard' ? "glowing-shadow-violet" : "glowing-shadow-pink"
            )}>
              {character === 'wizard' ? '🧙' : '🧚'}
            </div>
            
            <div className="text-center space-y-2">
              <h2 className={cn(
                "text-3xl font-headline font-black uppercase tracking-tighter",
                character === 'wizard' ? "text-primary" : "text-secondary"
              )}>
                {character === 'wizard' ? "The Vicious Sorcerer" : "The Fallen Fairy"}
              </h2>
              <p className="font-body text-sm text-muted-foreground max-w-xs mx-auto">
                {character === 'wizard' 
                  ? "Manifested from the deep obsidian void to wreak havoc on the mundane realm."
                  : "A fragment of pure malice, shed from the wings of a dark celestial being."}
              </p>
            </div>

            <div className="flex gap-4 pt-4">
              <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-[10px] font-bold uppercase tracking-widest text-accent">
                Level 99 Malice
              </div>
              <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-[10px] font-bold uppercase tracking-widest text-accent">
                Infinite Arcana
              </div>
            </div>
          </div>
          
          {/* Animated Background Sparks/Particles placeholder */}
          <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-accent/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        </div>
      </div>
    </div>
  );
}
