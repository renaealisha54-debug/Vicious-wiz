
"use client";

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Terminal, Trash2 } from 'lucide-react';
import { EventLogItem } from './ViciousWizardMain';
import { cn } from '@/lib/utils';

interface ArcaneEventLogProps {
  logs: EventLogItem[];
  onClear: () => void;
}

export function ArcaneEventLog({ logs, onClear }: ArcaneEventLogProps) {
  return (
    <Card className="vicious-card border-accent/20 h-[600px] flex flex-col">
      <CardHeader className="flex flex-row items-center justify-between border-b border-white/5 shrink-0">
        <div className="flex items-center gap-2">
          <Terminal className="text-accent h-5 w-5" />
          <CardTitle className="font-headline text-2xl">Arcane Event Log</CardTitle>
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={onClear}
          className="text-muted-foreground hover:text-destructive transition-colors"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="p-0 flex-1 overflow-hidden">
        <ScrollArea className="h-full">
          <div className="p-4 space-y-2 font-body text-sm">
            {logs.length === 0 ? (
              <div className="h-full flex items-center justify-center text-muted-foreground italic py-20 opacity-30">
                The grimoire is empty... for now.
              </div>
            ) : (
              logs.map((log) => (
                <div 
                  key={log.id} 
                  className="group flex gap-3 py-1 border-b border-white/[0.02] last:border-0 hover:bg-white/[0.02] transition-colors"
                >
                  <span className="text-muted-foreground/50 shrink-0 font-mono text-xs">
                    [{log.timestamp}]
                  </span>
                  <span className={cn(
                    "font-medium",
                    log.type === 'summon' && "text-primary",
                    log.type === 'action' && "text-secondary",
                    log.type === 'genai' && "text-accent",
                    log.type === 'system' && "text-muted-foreground italic"
                  )}>
                    {log.message}
                  </span>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
