
"use client";

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Wand2, Zap, Ghost, Trash2 } from 'lucide-react';
import { CharacterType } from './ViciousWizardMain';

interface SorcererControlHubProps {
  onSummon: (type: CharacterType) => void;
}

export function SorcererControlHub({ onSummon }: SorcererControlHubProps) {
  return (
    <Card className="vicious-card overflow-hidden">
      <CardHeader className="border-b border-white/5">
        <CardTitle className="flex items-center gap-2 font-headline text-2xl">
          <Zap className="text-accent h-5 w-5" />
          Sorcerer Hub
        </CardTitle>
        <CardDescription className="font-body text-xs">
          Direct your magical manifestations
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Button 
            onClick={() => onSummon('wizard')}
            className="h-24 flex flex-col gap-2 bg-primary hover:bg-primary/80 text-white rounded-xl border-b-4 border-black/20"
          >
            <span className="text-3xl animate-bob">🧙</span>
            <span className="font-headline font-bold text-xs uppercase tracking-widest">Summon Wizard</span>
          </Button>
          
          <Button 
            onClick={() => onSummon('fairy')}
            className="h-24 flex flex-col gap-2 bg-secondary hover:bg-secondary/80 text-white rounded-xl border-b-4 border-black/20"
          >
            <span className="text-3xl animate-bob">🧚</span>
            <span className="font-headline font-bold text-xs uppercase tracking-widest">Invoke Fairy</span>
          </Button>
        </div>

        <div className="pt-4 space-y-3">
          <div className="flex items-center justify-between text-xs font-body text-muted-foreground uppercase tracking-widest">
            <span>Overlay Settings</span>
            <Wand2 className="h-3 w-3" />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="w-full text-[10px] uppercase font-bold border-white/10 hover:bg-white/5">
              High Intensity
            </Button>
            <Button variant="outline" size="sm" className="w-full text-[10px] uppercase font-bold border-white/10 hover:bg-white/5">
              Glow FX: ON
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
