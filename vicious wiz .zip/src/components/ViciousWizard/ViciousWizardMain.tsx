"use client";

import React, { useState, useEffect } from 'react';
import { SorcererControlHub } from './SorcererControlHub';
import { ArcaneEventLog } from './ArcaneEventLog';
import { CharacterOverlay } from './CharacterOverlay';
import { VoidSpellCrafter } from './VoidSpellCrafter';
import { Toaster } from '@/components/ui/toaster';

export type EventLogItem = {
  id: string;
  timestamp: string;
  type: 'summon' | 'action' | 'genai' | 'system';
  message: string;
};

export type CharacterType = 'wizard' | 'fairy';

export function ViciousWizardMain() {
  const [logs, setLogs] = useState<EventLogItem[]>([]);
  const [activeCharacter, setActiveCharacter] = useState<CharacterType | null>(null);

  useEffect(() => {
    const savedLogs = localStorage.getItem('vicious_wizard_grimoire');
    if (savedLogs) {
      try {
        setLogs(JSON.parse(savedLogs));
      } catch (e) {
        console.error("Failed to load grimoire persistence", e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('vicious_wizard_grimoire', JSON.stringify(logs));
  }, [logs]);

  const addLog = (type: EventLogItem['type'], message: string) => {
    const newLog: EventLogItem = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toLocaleTimeString(),
      type,
      message,
    };
    setLogs(prev => [newLog, ...prev].slice(0, 100));
  };

  const summonCharacter = (type: CharacterType) => {
    setActiveCharacter(type);
    addLog('summon', `Summoned a vicious ${type} from the void.`);
    
    // Auto-clear overlay after 10 seconds unless interacted with
    setTimeout(() => {
      setActiveCharacter(prev => prev === type ? null : prev);
    }, 10000);
  };

  const clearGrimoire = () => {
    setLogs([]);
    addLog('system', "Grimoire has been purged.");
  };

  return (
    <div className="relative min-h-screen p-4 md:p-8 flex flex-col gap-8 max-w-7xl mx-auto">
      {/* Header Area */}
      <header className="flex flex-col items-center justify-center space-y-2 mb-4">
        <h1 className="text-4xl md:text-7xl font-headline font-black tracking-tighter gradient-header uppercase animate-shimmer">
          Vicious Wizard
        </h1>
        <p className="text-muted-foreground font-body text-sm tracking-widest uppercase">
          Master the arcane, purge the weak
        </p>
      </header>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Controls and AI Tool */}
        <div className="lg:col-span-4 space-y-6">
          <SorcererControlHub onSummon={summonCharacter} />
          <VoidSpellCrafter onLog={addLog} />
        </div>

        {/* Right Column: Event Log */}
        <div className="lg:col-span-8">
          <ArcaneEventLog logs={logs} onClear={clearGrimoire} />
        </div>
      </div>

      {/* Dynamic Overlay */}
      <CharacterOverlay 
        character={activeCharacter} 
        onClose={() => setActiveCharacter(null)} 
      />

      <Toaster />
    </div>
  );
}
