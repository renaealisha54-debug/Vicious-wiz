"use client";

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Flame, Loader2, Wand2, Sparkles, Moon } from 'lucide-react';
import { generateVoidSpell, type GenerateVoidSpellOutput } from '@/ai/flows/generate-void-spell';
import { useToast } from '@/hooks/use-toast';

interface VoidSpellCrafterProps {
  onLog: (type: 'genai', message: string) => void;
}

export function VoidSpellCrafter({ onLog }: VoidSpellCrafterProps) {
  const [category, setCategory] = useState('Necromancy');
  const [intensity, setIntensity] = useState([5]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GenerateVoidSpellOutput | null>(null);
  const { toast } = useToast();

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const output = await generateVoidSpell({
        category,
        intensity: intensity[0],
      });
      setResult(output);
      onLog('genai', `Crafted "${output.spellName}" (${category}). Intensity: ${intensity[0]}. Incantation: ${output.incantation}`);
    } catch (error) {
      toast({
        title: "Arcane Backfire",
        description: "The void destabilized. Spell crafting failed.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="vicious-card border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-headline text-xl">
          <Wand2 className="text-primary h-5 w-5" />
          Void Spell Crafter
        </CardTitle>
        <CardDescription className="text-xs font-body">
          Transmute shadow into pure destruction
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">Arcane School</Label>
          <Input 
            placeholder="e.g. Chaos, Shadow, Frost" 
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="bg-black/40 border-white/10 font-body text-sm"
          />
        </div>
        
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <Label className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">Malice Intensity</Label>
            <span className="text-xs font-bold text-accent">{intensity[0]}</span>
          </div>
          <Slider 
            value={intensity} 
            onValueChange={setIntensity} 
            max={10} 
            min={1} 
            step={1} 
            className="py-4"
          />
        </div>

        <Button 
          onClick={handleGenerate} 
          disabled={loading}
          className="w-full bg-primary hover:bg-primary/80 font-headline font-bold uppercase tracking-wider h-11 border-b-4 border-black/20"
        >
          {loading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Flame className="mr-2 h-4 w-4" />
          )}
          Forge Incantation
        </Button>

        {result && (
          <div className="mt-4 p-4 rounded-lg bg-black/40 border border-white/5 space-y-4 animate-in fade-in slide-in-from-top-2 duration-500">
            <div className="space-y-1">
              <h4 className="text-lg font-headline font-bold text-primary italic">"{result.spellName}"</h4>
              <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">{result.incantation}</p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-[10px] uppercase font-bold text-accent">
                <Sparkles className="h-3 w-3" />
                Manifestation
              </div>
              <p className="text-xs font-body text-muted-foreground leading-relaxed">
                {result.effect}
              </p>
            </div>

            <div className="pt-2 border-t border-white/5">
              <div className="flex items-center gap-2 text-[10px] uppercase font-bold text-destructive">
                <Moon className="h-3 w-3" />
                Required Sacrifice
              </div>
              <p className="text-[10px] font-body text-destructive/80 italic">
                {result.sacrifice}
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
